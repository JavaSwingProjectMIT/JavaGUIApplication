import java.sql.*;
public class Main {
//add
	public static void main(String[] args) throws SQLException {
	
		Login loginPage = new Login();
			
		}

}
