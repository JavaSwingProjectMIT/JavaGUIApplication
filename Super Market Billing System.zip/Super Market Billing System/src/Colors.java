import java.awt.Color;
import java.awt.Font;

public class Colors {
	//bg
	public static Color teal = new Color(43, 103, 119); 
	//paragraphs
	public static Color grey = new Color(242, 242, 242);
	public static Color darkGrey = new Color(200, 216, 229);
	public static Color darkGreyShadow2 = new Color(193, 208, 219);
	//Headings
	public static Color white = new Color(255,255,255);
	//Succes buttons
	public static Color aquaMarine = new Color(82, 171, 152);
	public static Color darkPurple = new Color(59,42,94);
	public static Color lightPurple = new Color (212, 199, 237);
	
	public static String font ="Comic Sans MS";
	
}
